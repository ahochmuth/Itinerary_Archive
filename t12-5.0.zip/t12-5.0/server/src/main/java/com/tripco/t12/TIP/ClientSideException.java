package com.tripco.t12.TIP;

public class ClientSideException extends Throwable {
}
