package com.tripco.t12.sql;

public class FilterException extends Throwable {
    public FilterException(String s) {
        super(s);
    }
}
