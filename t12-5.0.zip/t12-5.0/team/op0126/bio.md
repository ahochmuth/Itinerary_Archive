

Andre Hochmuth

Andre Hochmuth is a fourth year undergraduate at CSU. He works as a data-scientist intern for the Education Department at CSU and a barista for Sweet Sinsations in the Lory Student Center. He is studying Computer Science with minors in Mathematics and Applied Statistics. He will be graduating in Fall 2019. He enjoys the areas of artificial intelligence and data analysis. He wants to someday apply artificial intelligence to medical diagnostics in order to provide medical screening to those in need. He has lived in Fort Collins, CO his entire life.
