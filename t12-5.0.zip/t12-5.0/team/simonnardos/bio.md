Simon Nardos

I am currently a third year Computer Science major at Colorado State University. My interest in Computer Science comes from my passion for techonology; and in particular video games. I am from Denver, Colorado although my parents were born and raised in Ethiopia but moved to America shortly before conceiving me. 
