# Teamwork Questionnaire for _Simon Nardos_

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 

   * Text and groupchat apps are easiest to reach me and any hours work fine I will get back ASAP

1. __What are your expectations about what your team will accomplish this semester?__ 

   * I expect us to all grow as coders and to be confident for the real world

1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 

   * I plan to fully embrace this class and really treat it like an internship 

1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 

   * I imagine things will be difficult but plan on pushing through 

1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 

   * I think we wont have to worry about that with our group based on what i have seen from them in previous classes

1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 

   * I think everyone should do everything they can do to maximize the project and the grade will come

1. __How much time per week do you anticipate it will take to make the project successful?__ 

   * 15-20 hours

1. __How will you decide who should do what on the project and activities?__ 

   * I think we will come together and decide that as a group

1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 

   * Everyone will suffer but we must push through like the real world

1. __What happens if people have different opinions on the quality of the work?__ 

   * I think we will have to meet about it until an agreement is reached

1. __How will you deal with different work habits of team members?__ 

   * Communication will be key 

1. __Do you want to have a standing meeting time outside of class?__ 

   * i think that will vary from day to day just depending on our schedules and progress

1. __How often do you think the team will need to meet outside of class?__ 

   * As much as we possibly can

1. __Will you need approval of every team member before making a decision?__ 

   * Yes I want to receive everyones input before making decisions

1. __What will you do if every team member except one agrees on something?__ 

   * Disscuss it until a compromise is agreed upon
   
1. __What will you do if one person seems to be dominating the team process?__ 

   * Everyone must step it up in order to do their part

1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 

   * Distribute the responsibilities evenly
