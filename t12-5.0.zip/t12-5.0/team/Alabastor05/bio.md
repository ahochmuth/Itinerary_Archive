Mike Popesh

I am born and raised in northern Minnesota and moved to Colorado at the end of 2015. I enjoy solving puzzels/problems/riddles and also enjoy looking for meaning in numbers. My interest in computer science started with doing research on companies from a investment perspective where I saw the value data analytics. I am the founder/president of the Quantitative Hedge Fund Club here at CSU. Any career involving data analysis would interest me.  
