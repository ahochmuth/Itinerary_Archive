Nick ODell

I'm Nick. I enjoy biking, board games, and llama backpacking. I was born in Boulder, Colorado. I have a sister who graduated from CSU in biomechanical engineering. I currently work as an undergraduate teaching assistant. I volunteer through CSU's RamRide, and Boulder Food Rescue. I'm interested in compilers and low-level details of computers, and I'm looking for a career doing that.
