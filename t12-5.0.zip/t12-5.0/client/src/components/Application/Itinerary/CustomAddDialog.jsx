import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import {Button, Form, Input} from 'reactstrap';
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import Coordinates from 'coordinate-parser';
import Pane from '../Pane';

const errorStyle = {
    border: '1px solid red',
    width: '100%'
};

const noStyle = {
    width: '100%'
};

export default class CustomAddDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            name: '',
            coordinateString: '',
            coordinateError: false,
            nameError: false,
        };

        this.toggle = this.toggle.bind(this);
    }

    toggle() {
        this.setState(prevState => ({
            isOpen: !prevState.isOpen
        }));
    }

    render() {
        return (
            <React.Fragment>
                <Button style={{float: "right"}} onClick={this.toggle}>Add custom place</Button>
                {this.renderModal()}
            </React.Fragment>
        );
    }

    renderModal() {
        return (
            <Modal isOpen={this.state.isOpen} toggle={this.toggle} className={this.props.className} size="lg">
                <ModalHeader toggle={this.toggle}>Add a custom place</ModalHeader>
                <ModalBody>
                    {this.renderModalBody()}
                </ModalBody>
                <ModalFooter>
                    <Button onClick={this.toggle}>Done</Button>
                </ModalFooter>
            </Modal>
        );
    }

    renderModalBody() {
        return (
            <Form>
                {this.createCoordinateInputField()}
                {this.createNameInputField()}
                {this.addPlacesToItineraryButton()}
            </Form>
        );
    }

    createCoordinateInputField() {
        const updateCoordinateStateOnChange = (event) => {
            const coordinateString = event.target.value;
            this.setState({
                coordinateError: !this.isValidCoordinate(coordinateString),
                coordinateString: coordinateString,
            });
        };

        return (
            <Input name='Coordinate' placeholder={'Coordinates'}
                   onChange={updateCoordinateStateOnChange}
                   style={this.state.coordinateError ? errorStyle : noStyle}
                   value={this.state.coordinateString}
            />
        );
    }

    createNameInputField() {
        let updateNameStateOnChange = (event) => {
            let currentName = event.target.value;
            this.setState({
                name: currentName,
                nameError: !this.isValidName(currentName),
            });
        };

        return (
            <Input name='Name' placeholder={"Location Name"}
                   onChange={updateNameStateOnChange}
                   style={this.state.nameError ? errorStyle : noStyle}
                   value={this.state.name}
            />
        );
    }

    addPlacesToItineraryButton() {
        return (<Button style={{marginTop: 20, paddingLeft: 37, paddingRight: 37}}
                        onClick={() => this.addPlaceToItinerary()}>Add Location</Button>
        );
    }

    coordinateParse(coordinateString) {
        const parsed = new Coordinates(coordinateString);
        const latLong = {
            latitude: parsed.getLatitude().toString(),
            longitude: parsed.getLongitude().toString(),
        }
        return latLong;
    }

    isValidCoordinate(coordinateString) {
        try {
            new Coordinates(coordinateString);
            return true;
        } catch(e) {
            return false;
        }
    }

    isValidName(name) {
        return (/^[a-z A-Z]+$/.test(name));
    }

    addPlaceToItinerary() {
        if (this.isPlaceReadyToAdd()) {
            const { latitude, longitude } = this.coordinateParse(this.state.coordinateString);
            const place = {
                id: this.state.name,
                name: this.state.name,
                latitude: latitude,
                longitude: longitude,
            };
            this.props.addPlace(place);
            this.clearForm();
        }
        else {
            // TODO display message why it can't be added
            console.error("can't add place");
        }
    }

    clearForm() {
        this.setState({
            name: '',
            coordinateString: '',
            coordinateError: false,
            nameError: false,
        });
    }

    isPlaceReadyToAdd() {
        const { name, coordinateString } = this.state;
        return this.isValidName(name) &&
            this.isValidCoordinate(coordinateString);
    }
}
