import React, { Component } from 'react';
import {Button, Container, Table} from 'reactstrap';
import { Droppable } from 'react-beautiful-dnd';

import ItineraryHeader from './ItineraryHeader.jsx'
import ItineraryItem from './ItineraryItem.jsx'

export default class ItineraryList extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    // Bind needs to be done here, not in the constructor.
    // No, I don't know why.
    this.renderItems = this.renderItems.bind(this);

    return (
      <Droppable droppableId='itineraryDroppable'>
        {
          // Droppable expects to recieve a function that returns the Draggable objects
          // See https://medium.com/merrickchristensen/function-as-child-components-5f3920a9ace9
          // for an example of functions as children.
          this.renderItems
        }
      </Droppable>
    );
  };

  renderItems(provided) {
    const distances = this.props.distances;
    const cumulativeDistances = ItineraryList.calculateCumulativeDistances(distances);
    return (
      // Our DnD library requires that Dragables and Droppables are HTMLElements.
      // Therefore, this is a div.
      <div ref={provided.innerRef}
           {...provided.droppableProps} >
        <Table responsive>
          <ItineraryHeader
            attributesToShow={this.props.attributesToShow}
            activeUnit={this.props.activeUnit} />
          <tbody>
            {this.props.places.map((place, index) => {
              const distance = distances[index];
              const cumulativeDistance = cumulativeDistances[index];
              return this.renderItem(index, distance, cumulativeDistance, place);
            })}
            {provided.placeholder}
          </tbody>
        </Table>
      </div>
    );
  }

  renderItem(index, distance, cumulativeDistance, place) {
    let combinedPlace = Object.assign({}, place);
    combinedPlace.distance = distance;
    combinedPlace.cumulativeDistance = cumulativeDistance;

    return <ItineraryItem
        key={index}
        index={index}
        place={combinedPlace}
        markersChecked={this.props.markersChecked}
        updateMarkers={this.props.updateMarkers}
        attributesToShow={this.props.attributesToShow} />
  }

  static calculateCumulativeDistances(distances) {
    var cumulativeDistances = [];
    var total = 0;
    for(var i = 0; i < distances.length; i++) {
      total += distances[i];
      var newElement = total;
      if(isNaN(newElement)) {
        // One of the distances we need is not present.
        // We can't produce a meaningful total.
        newElement = "";
      }
      cumulativeDistances.push(total);
    }
    return cumulativeDistances;
  }
}
