import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import {Button} from 'reactstrap';
import {Form, Input} from 'reactstrap'
import {sendServerRequestWithBody} from '../../../api/restfulAPI';
import {DragDropContext} from 'react-beautiful-dnd'
import Coordinates from 'coordinate-parser';
import Pane from '../Pane';
import DisplayPicker from './DisplayPicker.jsx';
import ItineraryList from './ItineraryList.jsx';
import ItineraryMap from './ItineraryMap.jsx'
import FindAddDialog from './FindAddDialog.jsx'
import {saveFile, readFileAndCallbackOnLoad} from './file-utils.jsx';
import CustomAddDialog from './CustomAddDialog.jsx'


export default class Itinerary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            options: {},
            distances: [],
            errorMessage: null,
            attributesToShow: {internalNames: [], displayNames: []}
        };
        this.onDragEnd = this.onDragEnd.bind(this);
        this.reversePlaces = this.reversePlaces.bind(this);
        this.setAttributesToShow = this.setAttributesToShow.bind(this);
        this.addPlaceFromDialog = this.addPlaceFromDialog.bind(this);
        this.calculateItineraryDistancesIfRequired();
        // this.createCoordinateInputField = this.createCoordinateInputField.bind(this);
        // this.createNameInputField = this.createNameInputField.bind(this);
        this.showMarkers = this.showMarkers.bind(this);
        this.clearMarkers = this.clearMarkers.bind(this);
        
    }


    render() {
        return (
            <React.Fragment>
                {this.state.errorMessage}
                <Container>
                    <Row>
                        <Col xs={12} sm={12} md={7} lg={8} xl={9}>
                            <ItineraryMap updatePosition={this.props.updatePosition} position={this.props.position} places={this.props.places.map(this.parseCoordinatesOfPlace)} markersChecked={this.props.markersChecked} />
                        </Col>
                        <Col xs={12} sm={12} md={5} lg={4} xl={3}>
                            <Row className='center-itinerary'>
                                {this.displayUploadSave()}
                            </Row>
                            <Row className='center-itinerary'>
                                {this.displayOptimizations()}
                            </Row>
                            <Row className='center-itinerary'>
                                <div className="col">
                                {this.clearButton()}
                                </div>
                            </Row>
                        </Col>
                    </Row>
                    <Row>
                        <div className="col">
                        {this.displayTripDetails()}
                        </div>
                    </Row>
                </Container>
            </React.Fragment>

        );
    }

    displayUploadSave() {
        return (
            <Container>
                <Pane header={'Upload or Save Your Itinerary'}>
                    {this.uploadItineraryFromFile()}
                    <Button style={{marginTop: 20, paddingLeft: 37, paddingRight: 37}}
                            onClick={() => this.saveItineraryToFile()}>Save</Button>
                </Pane>
            </Container>
        );
    }

    clearButton(){
        return (
            <Pane header={"Start with a Fresh Itinerary"}>
                <Button onClick={() => this.clearItinerary()}>Clear</Button>
            </Pane>
        );
    }

    clearMarkers(){
        let mark = this.props.markersChecked;
        for (let i = 0; i < mark.length; i++){
            mark[i].markFlag = false
        }
        this.props.updateMarkers(mark)
    }

    showMarkers(){
        let mark = this.props.markersChecked;
        for (let i = 0; i < mark.length; i++){
            mark[i].markFlag = true
        }
        this.props.updateMarkers(mark)
    }

    clearItinerary(){
        this.props.updatePlaces([]);
        this.props.updateMarkers([]);
        if(this.fileInput) {
            this.fileInput.value = "";
        }
    }


    addTotalDistance(distances) {
        if (distances === undefined) {
            return 0;
        }
        let totalTripDistance = 0;
        for (let i = 0; i < distances.length; i++) {
            totalTripDistance += distances[i];
        }
        return totalTripDistance
    }

    // Code adapted from https://egghead.io/courses/beautiful-and-accessible-drag-and-drop-with-react-beautiful-dnd
    onDragEnd(result) {
        const { destination, source } = result;

        // If dropped outside of droppable area, Remove.
        if (!destination) {
            const draggedPlace = this.props.places[source.index];
            this.props.removeMarkerFromItinerary(draggedPlace.name)
            const newPlaces = Array.from(this.props.places);
            newPlaces.splice(source.index, 1);
            this.setState({
                distances: [], // Distances are no longer meaningful, since it's a new route
            });
            this.props.updatePlaces(newPlaces);
            return;
        }

        // Only have one Droppable, so the droppableId will always be itineraryDroppable
        if (destination.droppableId !== "itineraryDroppable") {
            throw "Unexpected droppableId";
        }
        if (source.droppableId !== "itineraryDroppable") {
            throw "Unexpected droppableId";
        }

        // If dragged and dropped to same place, ignore
        if (source.index === destination.index) {
            return;
        }

        const draggedPlace = this.props.places[source.index];
        const newPlaces = Array.from(this.props.places);
        newPlaces.splice(source.index, 1);
        newPlaces.splice(destination.index, 0, draggedPlace);

        this.setState({
            distances: [], // Distances are no longer meaningful, since it's a new route
        });
        this.props.updatePlaces(newPlaces);

        // componentDidUpdate will fire after this, and recalculate distances
    }

    reversePlaces() {
        // Same trip, but other direction

        // The spec doesn't say how reversal should be done. I interpret it to mean
        // that the starting location should always stay the same, but the rest of
        // the list is reversed. Instead of Boulder->Denver->Fort Collins->Boulder,
        // you do Boulder->Fort Collins->Denver->Boulder

        if (this.props.places.length < 3) {
            // 0 places, 1 place, and 2 places trips do not have anything happen when they
            // are reversed.
            return;
        }

        // Keep the starting location at the top of the list
        const startingPlace = this.props.places[0];
        const startingMarker = this.props.markersChecked[0];

        // Get a copy of the rest of the locations
        let newPlaces = this.props.places.slice(1);
        let newMarkers = this.props.markersChecked.slice(1);
        newPlaces.reverse();
        newMarkers.reverse();
        newPlaces.unshift(startingPlace);
        newMarkers.unshift(startingMarker);
        this.props.updatePlaces(newPlaces);
        this.props.updateMarkers(newMarkers);
    }

    displayOptimizations() {
        const toTitleCase = str => {
            const firstLetterUppercase = str.charAt(0).toUpperCase();
            const restOfString = str.slice(1);
            return firstLetterUppercase + restOfString;
        }

        const optimizationsWithoutShort = this.props.optimizations.slice(1);
        return (
            <Container>
                <Pane header="Make your trip shorter">
                    {optimizationsWithoutShort.map(opt =>
                        <Button
                            style={{marginRight: "0.5em"}}
                            onClick={() => this.optimizeTrip(opt)}
                            key={opt}>
                            {toTitleCase(opt)}
                        </Button>
                    )}
                </Pane>
            </Container>
        );
    }


    optimizeTrip(level) {
        this.calculateItineraryDistances(level);
    }

    displayTripDetails() {
        const buttonStyle = {float: "right", marginRight: "0.5em"};
        let totalTripDistance = this.addTotalDistance(this.state.distances);
        const title = this.state.options.title;

        return (
            <Pane header={"Trip Details" + (title ? (" for " + title) : "")}>
                <Container>
                    <Row>Total Distance: {totalTripDistance} {this.props.options.activeUnit}</Row>
                    <Row>
                        <Button style={buttonStyle} onClick={this.reversePlaces}>Reverse Trip</Button>
                        <Button style={buttonStyle} onClick={this.clearMarkers}>Clear Markers</Button>
                        <Button style={buttonStyle} onClick={this.showMarkers}>Show Markers</Button>
                        <FindAddDialog
                            settings={this.props.settings}
                            addPlace={this.addPlaceFromDialog}
                            filters={this.props.filters}/>
                        <CustomAddDialog
                            addPlace={this.addPlaceFromDialog} />
                    </Row>
                    <DisplayPicker
                        attributesChecked={this.props.attributesChecked}
                        setAttributesChecked={this.props.setAttributesChecked}
                        setAttributesToShow={this.setAttributesToShow}/>
                    <Row>Drag and drop to reorder</Row>
                    {this.displayDragAndDropTable()}
                </Container>
            </Pane>
        );
    }

    displayDragAndDropTable() {
        return (
            <DragDropContext
                onDragEnd={this.onDragEnd}>
                <ItineraryList
                    activeUnit={this.props.options.activeUnit}
                    places={this.props.places}
                    distances={this.state.distances}
                    markersChecked={this.props.markersChecked}
                    updateMarkers={this.props.updateMarkers}
                    addMarkerToItinerary={this.props.addMarkerToItinerary}
                    attributesToShow={this.state.attributesToShow}/>
            </DragDropContext>
        );
    }

    addPlaceFromDialog(place) {
        const { places } = this.props;
        let newPlaces = places.slice();
        newPlaces.push(place);
        this.props.addMarkerToItinerary(place.name);
        this.props.updatePlaces(newPlaces);
    }

    setAttributesToShow(attributesToShow) {
        this.setState({attributesToShow: attributesToShow});
    }


    //code is from https://medium.com/@ilonacodes/front-end-shorts-how-to-read-content-from-the-file-input-in-react-17f49b293909
    uploadItineraryFromFile() {
        const onFileLoadCallback = (fileContent) => {
            const uploadedItinerary = JSON.parse(fileContent);
            this.setState({
                options: uploadedItinerary.options
            });
            this.props.updatePlaces(uploadedItinerary.places);
            // componentDidUpdate will fire after this, and recalculate distances

            const nameList = uploadedItinerary.places.map((place) => place.name);
            this.props.addMultipleMarkersToItinerary(nameList);
        }

        const onFileClick = (event) => {
            event.target.value=''
        };


        return <div>
            <input type='file'
                   id='file'
                   className='input-file'
                   accept=''
                   ref={ref=> this.fileInput = ref}
                   onChange={event => readFileAndCallbackOnLoad(event, onFileLoadCallback)}
                   onClick={onFileClick}
            />
        </div>
    };

    //code from https://jsfiddle.net/koldev/cW7W5/
    saveItineraryToFile() {
        const object = {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": this.state.options,
            "places": this.props.places,
            "distances": this.state.distances
        };

        let fileName = "defaultItineraryFile";
        if (this.state.options.title !== undefined) {
            fileName = this.state.options.title.toString();
        }

        const json = JSON.stringify(object);
        saveFile(json, fileName);
    }


    calculateItineraryDistancesIfRequired() {
        if (this.props.places.length == 0) {
            // If it's zero places, we can figure it out without asking the server
            if(this.state.distances.length != 0) {
                this.setState({
                    distances: [],
                });
            }
        } else {
            this.calculateItineraryDistances();
        }
    }


    calculateItineraryDistances(optimizationLevel = "none") {
        let unmapCache = {}
        const TIPrequest = this.buildItineraryRequest(optimizationLevel, unmapCache);

        sendServerRequestWithBody('itinerary', TIPrequest, this.props.settings.serverPort)
            .then((response) => {
                this.onRequestCompletion(response, optimizationLevel, unmapCache);
            })
            .catch((err) => {
                console.error(err);
            });
    }

    buildItineraryRequest(optimizationLevel, unmapCache) {
        const { activeUnit } = this.props.options;
        const earthRadius = this.props.options.units[activeUnit].toString();
        const optionsCopy = Object.assign({}, this.state.options);
        optionsCopy.earthRadius = earthRadius;
        if (optimizationLevel !== "none") {
            optionsCopy.optimization = optimizationLevel;
        }
        const request = {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": optionsCopy,
            "places": this.props.places.map(p => this.parseCoordinatesOfPlaceAndCacheUnmap(p, unmapCache)),
            "distances": [],
        };
        return request;
    }

    parseCoordinatesOfPlaceAndCacheUnmap(place, unmapCache) {
        const newPlace = this.parseCoordinatesOfPlace(place);
        if (place !== newPlace) {
            // Horrible hack to support unparseCoordinatesOfPlace
            unmapCache[JSON.stringify(newPlace)] = place;
        }
        return newPlace;
    }

    unparseCoordinatesOfPlace(newPlace, unmapCache) {
        const newPlaceJSON = JSON.stringify(newPlace);
        const unparsed = unmapCache[newPlaceJSON];
        if (unparsed === undefined) {
            // newPlace is not in the cache
            // Either an error has happened, or it didn't need to be parsed
            // and therefore does not need to be unparsed.
            return newPlace;
        }
        return unparsed;
    }

    parseCoordinatesOfPlace(place) {
        // If both coordinates are numbers, no change is required
        if (!isNaN(place.latitude) && !isNaN(place.longitude)) {
            return place;
        }

        const coordinateString = place.latitude + "," + place.longitude;
        let coord;
        try {
            coord = new Coordinates(coordinateString);
        } catch (err) {
            // TODO handle error
        }
        const latitude = coord.getLatitude().toString();
        const longitude = coord.getLongitude().toString();

        // Copy to avoid changing original
        const newPlace = Object.assign({}, place);
        newPlace.latitude = latitude;
        newPlace.longitude = longitude;
        return newPlace;
    }

    onRequestCompletion(response, optimizationLevel, unmapCache) {
        if (response.statusCode >= 200 && response.statusCode <= 299) {
            this.setState({
                distances: response.body.distances,
                errorMessage: null
            });
            if (optimizationLevel !== "none") {
                const reorderedPlaces = response.body.places.map((p) => (
                    this.unparseCoordinatesOfPlace(p, unmapCache)
                ));
                this.props.updatePlaces(reorderedPlaces);
            }
        } else {
            this.setState({
                errorMessage: this.props.createErrorBanner(
                    response.statusText,
                    response.statusCode,
                    `Request to ${this.props.settings.serverPort} failed.`
                )
            });
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.places !== this.props.places) {
            // If places has been reordered, then we need to ask the server to recalc
            // all of the distances

            this.calculateItineraryDistancesIfRequired();
        }
    }
}
