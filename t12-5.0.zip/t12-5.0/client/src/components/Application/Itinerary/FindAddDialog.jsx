import React, { Component } from 'react';
import Select from 'react-select';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Input, ButtonToolbar, Dropdown, DropdownItem, DropdownMenu, DropdownToggle} from 'reactstrap';
import { Container, Row, Col } from 'reactstrap';
import { sendServerRequestWithBody } from '../../../api/restfulAPI';
import Application from '../Application'
import { Table, Thead, Tbody, Tr, Th, Td } from 'react-super-responsive-table'
import "react-super-responsive-table/dist/SuperResponsiveTableStyle.css"


const buttonStyle = {float: "right", marginRight: "0.5em"};

// code from https://reactstrap.github.io/components/modals/
export default class FindAddDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            haveResults: false,
            places: [],
            found: 0,
            errorBanner: null,
            searchText: '',
            filters: [],
            dropDownOpen : [],
            selectedOption: null,
            optionsSelected: []
        };

        this.toggle = this.toggle.bind(this);
        this.searchIgnoringEmpty = this.searchIgnoringEmpty.bind(this);
        this.renderPlace = this.renderPlace.bind(this);
        this.toggleDropDown = this.toggleDropDown.bind(this);
        this.updateFilterState = this.updateFilterState.bind(this);
        this.updateFilterState(this.props.filters);
    }

    // TODO: Autofocus search box
    // componentDidUpdate(prevProps, prevState) {
    //     if(prevState.isOpen == false &&
    //         this.state.isOpen === true) {
    //         setTimeout(() => {this.searchBox.focus()}, 1000);
    //     }
    // }

    //componentDidMount() {
     //   this.updateFilterState(this.props.filters);
    //}

    toggle() {
        this.setState(prevState => ({
            isOpen: !prevState.isOpen
        }));
    }

    render() {
        return (
            <div>
                <Button style={buttonStyle} onClick={this.toggle}>Add from database</Button>
                {this.renderModal()}
            </div>
        );
    }

    renderModal() {
        return (
            <Modal isOpen={this.state.isOpen} toggle={this.toggle} className={this.props.className} size="lg">
                <ModalHeader toggle={this.toggle}>Search for a place</ModalHeader>
                <ModalBody>
                    {this.state.errorBanner}
                    {this.renderFilters()}
                    {this.renderSearchBar()}
                    {this.renderSearchResults()}
                </ModalBody>
                <ModalFooter>
                    <Button onClick={this.toggle}>Done</Button>
                </ModalFooter>
            </Modal>
        );
    }

    renderSearchBar() {
        return (
            <Container style={{marginTop: 10}}>
                <Row>
                    <Col xs="9" sm="9" md="10" lg="10" xl="10">
                        <Input
                            ref={(searchBox) => this.searchBox = searchBox}
                            type="text"
                            name="searchBox"
                            onChange={(evt) => this.setState({searchText: evt.target.value})} />
                    </Col>
                    <Col xs="2" sm="2" md="1" lg="1" xl="1">
                        <Button onClick={this.searchIgnoringEmpty}>Search</Button>
                    </Col>
                </Row>
            </Container>
        );
    }

    renderSearchResults() {
        if(!this.state.haveResults) return null;

        const columns = ["ID", "Name", "Municipality", "Altitude", "Latitude", "Longitude"];
        const { places } = this.state;

        return (
            <React.Fragment>
                {this.renderNumberOfResults(places.length, this.state.found)}
                <Table>
                    <Thead>
                        <Tr>
                            {columns.map((columnName) =>
                                <Td key={columnName}>{columnName}</Td>)}
                            <Td></Td>
                        </Tr>
                    </Thead>
                    <Tbody>
                        {places.map(this.renderPlace)}
                    </Tbody>
                </Table>
            </React.Fragment>
        );
    }

    renderNumberOfResults(resultsShown, resultsTotal) {
        if(resultsTotal === 0) {
            return "Showing 0 results"
        }
        return `Showing 1-${resultsShown} of ${resultsTotal} results`
    }

    renderPlace(place) {
        const columns = ["id", "name", "municipality", "altitude"];
        const lat_long_columns = ["latitude", "longitude"];
        return (
            <Tr key={place.id}>
                {columns.map((columnName) =>
                    <Td key={columnName}>{place[columnName]}</Td>)}
                {lat_long_columns.map((columnName) =>
                    <Td key={columnName}>{parseFloat(place[columnName]).toFixed(5)}</Td>)}
                <Td>
                    <Button onClick={(e) => this.addPlace(place)}>
                        Add
                    </Button>
                </Td>
            </Tr>
        );
    }

    capitalizeLabel(label) {
        const firstLetterUppercase = label.charAt(0).toUpperCase();
        const restOfString = label.slice(1);
        return firstLetterUppercase + restOfString;
    }

    toggleDropDown(filterName) {
        let drops = this.state.dropDownOpen;
        drops[filterName] = !drops[filterName];
        this.setState({
            dropDownOpen: drops
        });
    }

    updateFilterState(filterArray) {
        let updateFilter = this.state.filters;
        let updateDropDownOpen = this.state.dropDownOpen;
        for (let i = 0;i < filterArray.length; i++) {
            const filter = filterArray[i];
            let newFilter = {};
            newFilter["name"] = filter.name;
            newFilter["values"] = [];
            updateFilter.push(newFilter);
            let newDrop = {};
            newDrop[filter.name] = false;
            updateDropDownOpen.push(newDrop);
        }
        this.state.filters = updateFilter;
        this.state.dropDownOpen = updateDropDownOpen;
    }

    renderFilters() {
        if (this.props.filters) {
            return (
                this.props.filters.map(filter =>
                    this.filterSwitch(filter))
            );
        }
    }

    filterSwitch(filter) {
        if (filter.name === "country") {
            return this.countriesSelect(filter);
        }else {
            return this.renderFilterDropdown(filter);
        }
    }

    renderFilterDropdown(filter) {
        return (<Dropdown isOpen={this.state.dropDownOpen[filter.name]}
                          toggle={() => this.toggleDropDown(filter.name)}
                          style={{marginRight: 10, marginLeft: 10, marginBottom: 10, marginTop: 10}}
                          key={filter.name}> Filters:
            <DropdownToggle caret>
                {this.capitalizeLabel(filter.name)}
            </DropdownToggle>
            <DropdownMenu>
                {filter.values.map(value => (
                    <Container key={value}>
                        <input
                            type="checkbox"
                            id={filter}
                            checked={this.isFilterChecked(filter.name, value)}
                            onChange={() => this.checkFilter(filter.name, value)}/>
                        <label htmlFor={filter}>{this.capitalizeLabel(value)}</label>
                    </Container>))}
            </DropdownMenu>
        </Dropdown>);
    }

    countriesSelect(filter) {
        this.state.options = this.generateCountryOptions(filter.values);
        const { selectedOption } = this.state;
        return(
            <Select name="countrySelect"
                    key="cSelect"
                    value={selectedOption}
                    onChange={(target) => this.optionChange(target)}
                    options={this.state.options}
                    placeholder="Filter by Country"
                    isMulti={true}
                    isSearchable={true}
                    clearable="false"/>
        );
    }

    optionChange(selectedOptions) {
        let country = "";
        const missing = this.getRemovedCountry(selectedOptions);
        if (missing === null) {
            country = selectedOptions[selectedOptions.length -1].label;
        } else {
            country = missing;
        }
        this.checkFilter("country", country);
        if (selectedOptions.length === 0) {
            this.clearCountryFilters();
        }
        this.setState({
            selectedOption: selectedOptions,
            optionsSelected: selectedOptions
        });

    }

    clearCountryFilters() {
        let temp = this.state.filters;
        for(let i=0; i < temp.length; i++) {
            if (temp[i].name === "country") {
                temp[i].values = [];
            }
        }
        this.setState({
            filters: temp
        })
    }

    getRemovedCountry(selectedOptions) {
        let isThere = false;
        for (let i =0; i < this.state.optionsSelected.length;i++) {
            for (let j =0; j < selectedOptions.length; j++) {
                if (this.state.optionsSelected[i].label === selectedOptions[j].label) {
                    isThere = true;
                }
            }
            if (!isThere) {
                return this.state.optionsSelected[i].label;
            }
            isThere = false;
        }
        return null;
    }

    generateCountryOptions(countryOptions) {
        let ra = [];
        for (let i=0; i < countryOptions.length; i++) {
            let country = countryOptions[i];
            let temp = { value: country, label: this.capitalizeLabel(country) };
            ra.push(temp);
        }
        return ra;
    }

    checkFilter(filterName, filterValue) {
        let filters = this.state.filters;
        let flag = false;
        for (let i = 0; i < filters.length; i++) {
            if (filters[i].name === filterName) {
                for (let j = 0; j<filters[i].values.length;j++) {
                    if (filters[i].values[j] === filterValue) {
                        filters[i].values.splice(j, 1);
                        flag = true;
                        break;
                    }
                }
                if (flag===false) {
                    filters[i].values.push(filterValue);
                }
            }
        }
        this.setState({filters : filters})
    }

    isFilterChecked(filterName, filterValue) {
        for (let i =0; i < this.state.filters.length; i++) {
            if (this.state.filters[i].name === filterName) {
                return this.state.filters[i].values.includes(filterValue);
            }
        }
        return false
    }

    addPlace(place) {
        this.props.addPlace(place);
    }

    searchIgnoringEmpty() {
        const searchTerm = this.state.searchText
        if(searchTerm != "") {
            this.search(searchTerm);
        } else {
            this.clearSearchResults();
        }
    }

    clearSearchResults() {
        this.setState({
            haveResults: false,
            places: [],
            found: 0,
        });
    }

    search(searchTerm) {
        const TIPrequest = this.buildFindRequest(searchTerm);

        sendServerRequestWithBody('find', TIPrequest, this.props.settings.serverPort)
            .then((response) => {
                if (response.statusCode >= 200 && response.statusCode <= 299) {
                    this.setState({
                        haveResults: true,
                        places: response.body.places,
                        found: response.body.found,
                        errorBanner: null,
                    });
                } else {
                    this.setState({
                        errorBanner: Application.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Request to ${this.props.settings.serverPort} failed.`
                        )
                    });
                    this.clearSearchResults();
                }
            })
            .catch((err) => {
                console.error(err);
            });
    }

    buildFindRequest(searchTerm) {
        return {
            requestType: "find",
            requestVersion: 4,
            match: searchTerm.toString(),
            narrow: this.state.filters,
            limit: 10,
            found: 0,
            places: [],

        };
    }
}
