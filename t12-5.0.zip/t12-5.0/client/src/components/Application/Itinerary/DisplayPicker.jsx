import React, { Component } from 'react';
import { Row, Col } from 'reactstrap';

const allAttributes = {
  internalNames: [
    "id",
    "name",
    "latitude",
    "longitude",
    "distance",
    "cumulativeDistance"
  ],
  displayNames: [
    "ID",
    "Name",
    "Latitude",
    "Longitude",
    "Distance",
    "Cumulative Distance"
  ],
};

let checkboxStyle = {
  marginRight: "0.5em",
  marginLeft: "2em",
};

export default class DisplayPicker extends Component {
  constructor(props) {
    super(props);
    this.onCheck = this.onCheck.bind(this);
    this.updateAttributesToShow = this.updateAttributesToShow.bind(this);
    this.updateAttributesToShow(this.props.attributesChecked);
  }

  render() {
    return (
      <Row>
        {allAttributes.internalNames.map(
          (internalName, index) => {
            let displayName = allAttributes.displayNames[index];
            let checked = this.props.attributesChecked[internalName];
            return (
              <div key={internalName}>
                <input
                  type="checkbox"
                  id={internalName}
                  style={checkboxStyle}
                  checked={checked}
                  onChange={this.onCheck} />
                <label htmlFor={internalName}>Display {displayName}</label>
              </div>
            );
          }
        )}
      </Row>
    );
  }

  onCheck(event) {
    let internalName = event.currentTarget.id;
    let isChecked = this.props.attributesChecked[internalName];
    const attributesCheckedCopy = Object.assign({}, this.props.attributesChecked);
    attributesCheckedCopy[internalName] = !isChecked;
    this.props.setAttributesChecked(attributesCheckedCopy);
    this.updateAttributesToShow(attributesCheckedCopy);
  }

  updateAttributesToShow(newAttributesChecked) {
    // A box was ticked or unticked.
    // Recalculate what attributes to show.
    let indexesShown = []
    allAttributes.internalNames.forEach((name, index) => {
      if(newAttributesChecked[name]) {
        // The checkbox is ticked
        indexesShown.push(index)
      }
    });

    const internalNames = indexesShown.map(
      (indexToShow) => allAttributes.internalNames[indexToShow]);
    const displayNames = indexesShown.map(
      (indexToShow) => allAttributes.displayNames[indexToShow]);

    const attributesToShow = {
      internalNames: internalNames,
      displayNames: displayNames,
    }

    this.props.setAttributesToShow(attributesToShow);
  }
}
