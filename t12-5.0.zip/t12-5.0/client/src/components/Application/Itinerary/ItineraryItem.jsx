import React, { Component } from 'react';
import { Row, Col, Button } from 'reactstrap';
import { Draggable } from 'react-beautiful-dnd';
import {Marker, Popup} from "react-leaflet";
import markerHide from '../../Assets/marker-hide.png';
import markerShow from '../../Assets/marker-show.png';

export default class ItineraryItem extends Component {
  constructor(props) {
    super(props);
    this.toggleMarker = this.toggleMarker.bind(this);
  }

  render() {
    const { id } = this.props.place;
    const renderPlace = this.renderPlace.bind(this);
    return (
      <Draggable draggableId={id} index={this.props.index}>
        {renderPlace}
      </Draggable>
    );
  }

  renderPlace(provided) {
    const { place } = this.props;
    const internalNames = this.props.attributesToShow.internalNames;
    return (
      <tr key={place.id}
          ref={provided.innerRef}
          style={{backgroundColor: 'black'}}
          {...provided.draggableProps}
          {...provided.dragHandleProps}>
        <td>
          {this.renderToggleMarkerButton()}
        </td>
        {internalNames.map((attributeName) => (
            <td key={attributeName}
              style={{backgroundColor: 'white'}}>
            {place[attributeName]}
          </td>
        ))}
      </tr>
    );
  }

  toggleMarker() {
    let {markersChecked} = this.props;
    for (let i = 0; i < markersChecked.length; i++) {
      if (this.props.place.name === markersChecked[i].name) {
        markersChecked[i].markFlag = !markersChecked[i].markFlag;
        this.props.updateMarkers(markersChecked);
      }
    }
  }

  renderToggleMarkerButton() {
    const marked = this.isMarked(this.props.place.name);

    // If the image is currently marked, show a normal marker symbol.
    // If it isn't marked, show a greyed out marker symbol.
    // When the user clicks it, toggle between shown and not-shown.
    const markerIconImage = marked ? markerShow : markerHide;
    return (
      <img
        src={markerIconImage}
        onClick={this.toggleMarker}
        height="30em"/>
    );
  }

  isMarked(name){
    for(let i = 0; i < this.props.markersChecked.length; i++){
      if(name === this.props.markersChecked[i].name){
        return this.props.markersChecked[i].markFlag
      }
    }
    return false;
  }
}
