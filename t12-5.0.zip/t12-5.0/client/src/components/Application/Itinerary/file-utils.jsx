//code from https://jsfiddle.net/koldev/cW7W5/
export const saveFile = (data, fileName) => {
  const link = document.createElement("a");
  document.body.appendChild(link);
  link.style = "display: none";
  const blob = new Blob([data], {type: "octet/stream"});
  const url = window.URL.createObjectURL(blob);
  link.href = url;
  link.download = fileName;
  link.click();
  window.URL.revokeObjectURL(url);
};

//code is from https://medium.com/@ilonacodes/front-end-shorts-how-to-read-content-from-the-file-input-in-react-17f49b293909
export const readFileAndCallbackOnLoad = (event, onFileLoad) => {
  const firstFile = event.target.files[0];
  const fileReader = new FileReader();
  const handleFileRead = (ignoredEvent) => {
    const fileContent = fileReader.result;
    onFileLoad(fileContent);
  };
  fileReader.onloadend = handleFileRead;
  fileReader.readAsText(firstFile);
};
