import React, { Component } from 'react';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import { Map, Marker, Popup, TileLayer, Polyline } from 'react-leaflet';
import Pane from '../Pane';
import {Button} from "reactstrap";
import L from "leaflet";

export default class ItineraryMap extends Component {
    constructor(props) {
        super(props);

        this.componentDidMount = this.componentDidMount.bind(this);
        this.geoFail = this.geoFail.bind(this);
        this.geoSuccess = this.geoSuccess.bind(this);
    }

    render() {
        return (
            <Pane header={'Where Am I?'}>
                {this.renderLeafletMap()}
            </Pane>
        );
    }

    renderLeafletMap() {
        // initial map placement can use either of these approaches:
        // 1: bounds={this.coloradoGeographicBoundaries()}
        // 2: center={this.csuOvalGeographicCoordinates()} zoom={10}
        let bounds = L.latLngBounds(L.latLng(41, -109), L.latLng(37, -102));
        if (this.props.places.length > 1) {
            bounds = this.calculateBounds()
        }
        if (this.props.places.length < 1) {
            return (
                <Map center={this.props.position} zoom={14}
                     style={{height: 500, maxwidth: 700}}>
                    <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"/>
                    <Marker position={this.props.position}
                            icon={this.markerIcon()}>
                        <Popup className="font-weight-extrabold">Colorado State University</Popup>
                    </Marker>
                </Map>
            )
        }
        return (
            <Map bounds={bounds}
            style={{height: 500, maxwidth: 700}}>
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;> OpenStreetMap</a> contributors"
                />
                {this.generateAllLines()}
                {this.markerGenerator()}

            </Map>
                )
    }

    calculateBounds() {
        let x = this.props.places.map((p) =>
            L.latLng(p.latitude, p.longitude)
        )
        return x;
    }

    generateAllLines() {
        let lines = [];
        const {places} = this.props;
        for (let current_index = 0; current_index < places.length; current_index++) {
            const next_index = (current_index + 1) % places.length;
            const current_element = places[current_index];
            const next_element = places[next_index];
            lines.push(this.generateLine(current_element, next_element, current_index));
        }
        return lines;
    }

    generateLine(startingPlace, endingPlace, key) {
        const positions = [
            L.latLng(startingPlace.latitude, startingPlace.longitude),
            L.latLng(endingPlace.latitude, endingPlace.longitude),
        ];
        const liner = <Polyline
            color="green"
            positions={positions}
            key={key}/>
        return liner;
    }

    markerGenerator() {
        let mark = [];
        if (this.props.places.length < 1) {
            return
        }
        return this.props.places.map((p, index) => {
            if (this.isMarked(p.name)){
            return (<Marker position={L.latLng(p.latitude, p.longitude)}
                            icon={this.markerIcon()}
                            key={p.id}>
                <Popup className="font-weight-extrabold">{p.name}</Popup>
            </Marker>)}
        })
    }

    isMarked(name){
        for(let i = 0; i < this.props.markersChecked.length; i++){
            if(name === this.props.markersChecked[i].name){
                return this.props.markersChecked[i].markFlag
            }
        }
    }



    markerIcon() {
        // react-leaflet does not currently handle default marker icons correctly,
        // so we must create our own
        return L.icon({
            iconUrl: icon,
            shadowUrl: iconShadow,
            iconAnchor: [12, 40]  // for proper placement
        })
    }

    componentDidMount() {
        if(navigator.geolocation != undefined) {
            navigator.geolocation.getCurrentPosition(this.geoSuccess, this.geoFail, {timeout: 20000,maximumAge: 1000});
        } else {
            this.geoFail("Browser does not support geolocation")
        }
    }

    geoSuccess(position) {
        this.props.updatePosition(position);
        console.log("Location Successfully Set")
    }

    geoFail(error) {
        console.log("GeoFail");
        console.log(error);
    }
}
