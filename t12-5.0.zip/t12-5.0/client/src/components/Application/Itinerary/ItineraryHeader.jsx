import React, { Component } from 'react';
import {Row, Col, Button} from 'reactstrap';

export default class ItineraryHeader extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { displayNames } = this.props.attributesToShow;
    const { activeUnit } = this.props;
    return (
      <thead>
        <tr>
          <th>
            <b>Marker</b>
          </th>
          {displayNames.map((attributeName) => {
            if(attributeName.includes("Distance")) {
              // This is Distance or Cumulative Distance
              // Add a unit
              return <th key={attributeName}><b>{attributeName} ({activeUnit})</b></th>
            } else {
              return <th key={attributeName}><b>{attributeName}</b></th>
            }
          })}
        </tr>
      </thead>
    );
  }
}
