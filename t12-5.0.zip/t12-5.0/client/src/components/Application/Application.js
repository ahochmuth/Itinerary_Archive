import React, {Component} from 'react';
import {Card, CardBody, CardHeader, Container} from 'reactstrap';

import Home from './Home';
import Options from './Options/Options';
import Itinerary from './Itinerary/Itinerary';
import Calculator from './Calculator/Calculator';
import Settings from './Settings/Settings';
import Team from './Team/Team';
import {getOriginalServerPort, sendServerRequest} from '../../api/restfulAPI';
import ErrorBanner from './ErrorBanner';
import L from "leaflet";

/* Renders the application.
 * Holds the destinations and options state shared with the trip.
 */
export default class Application extends Component {
  constructor(props) {
    super(props);

    this.updatePlanOption = this.updatePlanOption.bind(this);
    this.updateClientSetting = this.updateClientSetting.bind(this);
    this.createApplicationPage = this.createApplicationPage.bind(this);
    this.updatePlaces = this.updatePlaces.bind(this);
    this.setAttributesChecked = this.setAttributesChecked.bind(this);
    this.updateLocationOnChange = this.updateLocationOnChange.bind(this);
    this.updateDistance = this.updateDistance.bind(this);
    this.updateMarkers = this.updateMarkers.bind(this);
    this.addMarkerToItinerary = this.addMarkerToItinerary.bind(this);
    this.addMultipleMarkersToItinerary = this.addMultipleMarkersToItinerary.bind(this);
    this.removeMarkerFromItinerary = this.removeMarkerFromItinerary.bind(this);
    this.updatePosition = this.updatePosition.bind(this);

    this.state = {
      serverConfig: null,
      planOptions: {
        units: {
          'miles': 3959,
          'kilometers': 6371,
          'nautical miles': 3440
        },
        activeUnit: 'miles',
      },
      clientSettings: {
        serverPort: getOriginalServerPort()
      },
      places: [],
      position: L.latLng(40.576179, -105.080773),
      attributesChecked: {
        id: true,
        name: true,
        latitude: true,
        longitude: true,
        distance: true,
        cumulativeDistance: true,
      },
      markersChecked: [],
      locations: {
        origin: {coordinates: '', error: false},
        destination: {coordinates: '', error: false},
      },
      distance: "-",
      errorMessage: null,
    };

    this.updateServerConfig();
  }

  render() {
    let pageToRender = this.state.serverConfig ? this.props.page : 'settings';

    return (
      <div className='application-width'>
        {this.state.errorMessage}{this.createApplicationPage(pageToRender)}
      </div>
    );
  }

  updateClientSetting(field, value) {
    if (field === 'serverPort')
      this.setState({clientSettings: {serverPort: value}}, this.updateServerConfig);
    else {
      let newSettings = Object.assign({}, this.state.planOptions);
      newSettings[field] = value;
      this.setState({clientSettings: newSettings});
    }
  }

  updatePlanOption(option, value) {
    let optionsCopy = Object.assign({}, this.state.planOptions);
    optionsCopy[option] = value;
    this.setState({'planOptions': optionsCopy});
  }

  updatePosition(position){
    this.setState({position:  L.latLng(position.coords.latitude, position.coords.longitude)});
  }

  updateServerConfig() {
    sendServerRequest('config', this.state.clientSettings.serverPort).then(config => {
      this.processConfigResponse(config);
    });
  }

  updatePlaces(array) {
    this.setState({'places': array})
  }

  updateMarkers(array){
    this.setState({'markersChecked': array})
  }

  addMultipleMarkersToItinerary(placeNameList) {
    let copyMarkersChecked = this.state.markersChecked.slice();
    placeNameList.forEach((placeName) => {
      const mark = {name: placeName, markFlag: false};
      copyMarkersChecked.push(mark)
    });
    this.updateMarkers(copyMarkersChecked)
  }

  addMarkerToItinerary(placeName){
    const mark = {name: placeName, markFlag: false}
    let copy = this.state.markersChecked
    copy.push(mark)
    this.updateMarkers(copy)
  }

  removeMarkerFromItinerary(placeName) {
    let copy = this.state.markersChecked
    for (let i = 0; i < copy.length; i++){
      if (placeName === copy[i].name){
        copy.splice(i, 1);
      }
    }
    this.updateMarkers(copy)
  }


  setAttributesChecked(attributesChecked) {
    this.setState({attributesChecked: attributesChecked})
  }

  updateLocationOnChange(locations) {
    this.setState({locations: locations})
  }

  static createErrorBanner(statusText, statusCode, message) {
    return (
      <ErrorBanner statusText={statusText}
                   statusCode={statusCode}
                   message={message}/>
    );
  }

  updateDistance(distance) {
    this.setState({distance: distance})
  }


  createApplicationPage(pageToRender) {
    switch (pageToRender) {
      case 'calc':
        return <Calculator options={this.state.planOptions}
                           settings={this.state.clientSettings}
                           locations={this.state.locations}
                           distance={this.state.distance}
                           updateDistance={this.updateDistance}
                           updateLocationOnChange={this.updateLocationOnChange}/>;
      case 'options':
        return <Options options={this.state.planOptions}
                        config={this.state.serverConfig}
                        updateOption={this.updatePlanOption}/>;
      case 'settings':
        return <Settings settings={this.state.clientSettings}
                         serverConfig={this.state.serverConfig}
                         updateSetting={this.updateClientSetting}/>;
      case 'team':
        return <Team/>
      case 'itinerary':
      default:
        return <Itinerary options={this.state.planOptions}
                          places={this.state.places}
                          position={this.state.position}
                          markersChecked={this.state.markersChecked}
                          attributesChecked={this.state.attributesChecked}
                          requestVersion={this.state.serverConfig.requestVersion}
                          optimizations={this.state.serverConfig.optimizations}
                          settings={this.state.clientSettings}
                          filters={this.state.serverConfig.filters}
                          updateOption={this.updatePlanOption}
                          updatePlaces={this.updatePlaces}
                          updateMarkers={this.updateMarkers}
                          updatePosition={this.updatePosition}
                          addMarkerToItinerary={this.addMarkerToItinerary}
                          addMultipleMarkersToItinerary={this.addMultipleMarkersToItinerary}
                          removeMarkerFromItinerary={this.removeMarkerFromItinerary}
                          setAttributesChecked={this.setAttributesChecked}
                          createErrorBanner={this.createErrorBanner}/>;
    }
  }

  processConfigResponse(config) {
    if (config.statusCode >= 200 && config.statusCode <= 299) {
      console.log("Switching to server ", this.state.clientSettings.serverPort);
      this.setState({
        serverConfig: config.body,
        errorMessage: null
      });
    } else {
      this.setState({
        serverConfig: null,
        errorMessage:
          <Container>
            {this.createErrorBanner(config.statusText, config.statusCode,
              `Failed to fetch config from ${this.state.clientSettings.serverPort}. Please choose a valid server.`)}
          </Container>
      });
    }
  }
}
