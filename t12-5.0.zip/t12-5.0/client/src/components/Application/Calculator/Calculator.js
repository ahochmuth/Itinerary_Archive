import React, {Component} from 'react'
import {Container, Row, Col} from 'reactstrap'
import {Button} from 'reactstrap'
import {Form, Label, Input, Alert} from 'reactstrap'
import {sendServerRequestWithBody} from '../../../api/restfulAPI'
import Coordinates from 'coordinate-parser'
import Pane from '../Pane'
import Application from '../Application'
import PropTypes from 'prop-types'

const errorStyle = {
    border: '1px solid red',
    width: '100%'
};

const noStyle = {
    width: '100%'
};

/* Renders the Calculator Tab.
 * Sends the server request to calculate the distance between two coordinate points.
 */
export default class Calculator extends Component {
    constructor(props) {
        super(props);
        this.isConstructed = false;

        this.updateLocationOnChange = this.updateLocationOnChange.bind(this);
        this.calculateDistance = this.calculateDistance.bind(this);
        this.createInputField = this.createInputField.bind(this);

        this.state = {
            errorMessage: null
        };

        this.calculateDistance();
        this.isConstructed = true;
    }

    render() {
        return (
            <Container fluid style={{lineHeight: '32px'}}>
                {this.state.errorMessage}
                <Row align="start">
                    <Col xs="auto" sm="auto" md="auto" lg="12" xl="9">
                        {this.createHeader()}
                    </Col>
                </Row>
                <Row nogutter="true">
                    <Col xs="12" sm="12" md="6" lg="4" xl="3">
                        {this.createForm('origin')}
                    </Col>
                    <Col xs="12" sm="12" md="6" lg="4" xl="3">
                        {this.createForm('destination')}
                    </Col>
                    <Col xs="12" sm="12" md="6" lg="4" xl="3">
                        {this.displayDistance()}
                    </Col>
                </Row>
            </Container>
        );
    }

    createHeader() {
        return (
            <Pane header={'Calculator'}>
                <div>
                    Determine the distance between the origin and destination.
                    Change the units on the <b>Options</b> page.
                </div>
            </Pane>
        );
    }

    createInputField(stateVar) {
        let updateStateVarOnChange = (event) => {
            this.updateLocationOnChange(stateVar, event.target.value)
        };

        let capitalizedCoordinate = 'Coordinates';
        return (
            <Input name='coordinates' placeholder={capitalizedCoordinate}
                   id={`${stateVar}${capitalizedCoordinate}`}
                   value={this.props.locations[stateVar].coordinates}
                   onChange={updateStateVarOnChange}
                   style={this.props.locations[stateVar].error ? errorStyle : noStyle}
            />
        );

    }

    createForm(stateVar) {
        return (
            <Pane header={stateVar.charAt(0).toUpperCase() + stateVar.slice(1)}>
                <Form>
                    {this.createInputField(stateVar)}
                </Form>
            </Pane>
        );
    }

    displayDistance() {
        return (
            <Pane header={'Distance'}>
                <Row>
                    <Col xs="auto">
                        <h5>{this.props.distance} {this.props.options.activeUnit}</h5>
                    </Col>
                    <Col xs="3">
                        <Button onClick={this.calculateDistance}>Calculate</Button>
                    </Col>
                </Row>
            </Pane>
        );
    }

    isCoordinateValid(coordinateString) {
        try {
            new Coordinates(coordinateString);
            return true;
        } catch (err) {
            return false;
        }
    }

    coordinateParse(coordinateString) {
        try {
            var parsed = new Coordinates(coordinateString);
        } catch (e) {
            // Invalid coordinate
            return null;
        }
        const latLong = {
            latitude: parsed.getLatitude().toString(),
            longitude: parsed.getLongitude().toString(),
        }
        return latLong;
    }

    calculateDistance() {
        const {origin, destination} = this.props.locations;
        const originParsed = this.coordinateParse(origin.coordinates);
        const destinationParsed = this.coordinateParse(destination.coordinates);

        // If coordinates are invalid, don't send request
        if (!this.validateCoordinates(originParsed, destinationParsed)) {
            this.props.updateDistance("-");
            return;
        }

        const earthRadius = this.props.options.units[this.props.options.activeUnit];
        const tipDistanceRequest = this.buildDistanceRequest(originParsed, destinationParsed, earthRadius);

        sendServerRequestWithBody('distance', tipDistanceRequest, this.props.settings.serverPort)
            .then((response) => {
                if (response.statusCode >= 200 && response.statusCode <= 299) {
                    this.setState({
                        errorMessage: null
                    });
                    this.props.updateDistance(response.body.distance.toString())
                } else {
                    this.setState({
                        errorMessage: Application.createErrorBanner(
                            response.statusText,
                            response.statusCode,
                            `Request to ${this.props.settings.serverPort} failed.`
                        )
                    });
                }
            }).catch((err) => {
            console.error(err);
        })
    }

    validateCoordinates(origin, destination) {
        if (origin === null) {
            this.showClientSideError("Invalid origin coordinates");
            return false;
        }
        if (destination === null) {
            this.showClientSideError("Invalid destination coordinates");
            return false;
        }
        return true;
    }

    buildDistanceRequest(origin, destination, earthRadius) {
        const tipDistanceRequest = {
            requestType: "distance",
            requestVersion: 4,
            origin: origin,
            destination: destination,
            earthRadius: earthRadius,
        };
        return tipDistanceRequest;
    }

    updateLocationOnChange(stateVar, value) {
        let locationsCopy = Object.assign({}, this.props.locations);
        let valueStr = value.toString();
        let location = {
            coordinates: valueStr,
            error: !this.isCoordinateValid(valueStr),
        }
        locationsCopy[stateVar] = location;
        this.props.updateLocationOnChange(locationsCopy)
    }

    showClientSideError(errorMessage) {
        if (this.isConstructed) {
            this.setState({
                errorMessage: this.errorConstructor(errorMessage)
            });
        }
    }

    errorConstructor(errorMessage) {
        return (
            <Alert className='bg-csu-canyon text-white font-weight-extrabold'>
                {errorMessage}
            </Alert>
        );
    }
}

Calculator.propTypes = {
    locations: PropTypes.object.isRequired,
    distance: PropTypes.string.isRequired,
    options: PropTypes.object.isRequired,
    settings: PropTypes.object.isRequired,
    updateDistance: PropTypes.func.isRequired,
    updateLocationOnChange: PropTypes.func.isRequired,
}
