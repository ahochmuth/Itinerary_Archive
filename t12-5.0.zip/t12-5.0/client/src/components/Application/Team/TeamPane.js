import React, {Component} from 'react';
import {Col} from 'reactstrap';
import {CardHeader, Card, CardImg} from 'reactstrap';

/**
 * The TeamPane component.
 * Provides info about one person.
 */
export default class Team extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Col xs="12" sm="12" md="6" lg="3">
        <Card>
          <CardImg src={this.props.image} alt={this.props.alt} text={this.props.text} name={this.props.name}/>
          {this.props.children}
          <Card>
            <CardHeader className='bg-csu-gold text-white font-weight-semibold text-center"'>
              {this.props.name}
            </CardHeader>
          </Card>
          <Card className="text-center" body outline color="secondary">{this.props.text}</Card>
        </Card>
      </Col>
    );
  }
}
