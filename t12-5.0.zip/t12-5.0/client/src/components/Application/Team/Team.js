import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import Pane from '../Pane';
import TeamPane from './TeamPane.js'

// import team pictures
import andre from '../../../../../team/op0126/poop.jpg';
import mike from '../../../../../team/Alabastor05/mp.jpg';
import simon from '../../../../../team/simonnardos/Image.jpg';
import nick from '../../../../../team/nickodell/nickodell.jpg';

/**
 * The Team component.
 * Provides info about the people who made it.
 */
export default class Team extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Container>
        <Row>
          <TeamPane image={mike} alt="picture of no expression" name="Mike Popesh"
                    text="I am born and raised in northern Minnesota and moved to Colorado at the end of 2015. I enjoy solving puzzels/problems/riddles and also enjoy looking for meaning in numbers. My interest in computer science started with doing research on companies from a investment perspective where I saw the value data analytics. I am the founder/president of the Quantitative Hedge Fund Club here at CSU. Any career involving data analysis would interest me.">
          </TeamPane>
          <TeamPane image={nick} alt="picture of no expression" name="Nick ODell"
                    text="I'm Nick. I enjoy biking, board games, and llama backpacking. I was born in Boulder, Colorado. I have a sister who graduated from CSU in biomechanical engineering. I currently work as an undergraduate teaching assistant. I volunteer through CSU's RamRide, and Boulder Food Rescue. I'm interested in compilers and low-level details of computers, and I'm looking for a career doing that.">
          </TeamPane>
          <TeamPane image={andre} alt="picture of no expression" name="Andre Hochmuth"
                    text="Andre Hochmuth is a fourth year undergraduate at CSU. He works as a data-scientist intern for the Education Department at CSU and a barista for Sweet Sinsations in the Lory Student Center. He is studying Computer Science with minors in Mathematics and Applied Statistics. He will be graduating in Fall 2019. He enjoys the areas of artificial intelligence and data analysis. He wants to someday apply artificial intelligence to medical diagnostics in order to provide medical screening to those in need. He has lived in Fort Collins, CO his entire life.">
          </TeamPane>
          <TeamPane image={simon} alt="picture of no expression" name="Simon Nardos"
                    text="I am currently a third year Computer Science major at Colorado State University. My interest in Computer Science comes from my passion for techonology; and in particular video games. I am from Denver, Colorado although my parents were born and raised in Ethiopia but moved to America shortly before conceiving me.">
          </TeamPane>
        </Row>
      </Container>
    );
  }

}
