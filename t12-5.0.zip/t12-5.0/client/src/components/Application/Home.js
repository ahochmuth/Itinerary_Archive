import React, {Component} from 'react';
import {Container, Row, Col} from 'reactstrap';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import {Map, Marker, Popup, TileLayer} from 'react-leaflet';
import Pane from './Pane'
import L from 'leaflet';


export default class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      position: L.latLng(40.576179, -105.080773)
    };
    this.componentDidMount = this.componentDidMount.bind(this);
    this.geoFail = this.geoFail.bind(this);
    this.geoSuccess = this.geoSuccess.bind(this);
  }

  render() {
    return (
      <Container>
        <Row>
          <Col xs={12} sm={12} md={7} lg={8} xl={9}>
            {this.renderMap()}
          </Col>
          <Col xs={12} sm={12} md={5} lg={4} xl={3}>
            {this.renderIntro()}
          </Col>
        </Row>
      </Container>
    );
  }

  renderMap() {
    return (
      <Pane header={'Where Am I?'}>
        {this.renderLeafletMap()}
      </Pane>
    );
  }

  renderLeafletMap() {
    return (<Map center={this.state.position} zoom={14}
                 style={{height: 500, maxwidth: 700}}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"/>
      <Marker position={this.state.position}
              icon={this.markerIcon()}>
        <Popup className="font-weight-extrabold">Colorado State University</Popup>
      </Marker>
    </Map>)
  }

  markerIcon() {
    return L.icon({
      iconUrl: icon,
      shadowUrl: iconShadow,
      iconAnchor: [12, 40]  // for proper placement
    })
  }

  renderIntro() {
    return (
      <Pane header={'Bon Voyage!'}>
        Let us help you plan your next trip.
      </Pane>
    );
  }

  componentDidMount() {
    if(navigator.geolocation != undefined) {
      navigator.geolocation.getCurrentPosition(this.geoSuccess, this.geoFail, {timeout: 20000,maximumAge: 1000});
    } else {
      this.geoFail("Browser does not support geolocation")
    }
  }

  geoSuccess(position) {
    this.setState({position:  L.latLng(position.coords.latitude, position.coords.longitude)});
    console.log("Location Successfully Set")
  }

  geoFail(error) {
    console.log("GeoFail");
    console.log(error);
  }

}
