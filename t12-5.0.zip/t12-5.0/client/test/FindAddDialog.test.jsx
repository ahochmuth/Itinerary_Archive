import './enzyme.config.js';
import React from 'react';
import { mount, shallow } from 'enzyme';
import { Button } from 'reactstrap';
import FindAddDialog from '../src/components/Application/Itinerary/FindAddDialog.jsx';
import {findButton} from './test-utils.js';

const singleFilters = [{"name": "type",
    "values": ["airport","heliport","balloonport","closed"]}
    ];

const doubleFilters = [
    {"name": "type", "values": ["airport","heliport","balloonport","closed"]},
    {"name": "country", "values": ["Poland", "Brazil"]}
];

function testRenderDialog() {
    let fad = mount(<FindAddDialog filters={singleFilters}/>);
}
test("Test that dialog renders without exceptions", testRenderDialog)


function testDialogOpen() {
    let fad = mount(<FindAddDialog filters={singleFilters}/>);
    let button = findButton(fad, "Add from database")
    button.prop('onClick')();
    let modalOpen = fad.state().isOpen;
    expect(modalOpen).toEqual(true);
}
test("Test that dialog opens", testDialogOpen)

function testCorrectFilters() {
    let narrow = [{"name":"type", "values":[]}];
    let find = mount(<FindAddDialog filters={narrow}/>);
    let yum = find.instance().buildFindRequest('tacos');
    expect(yum.narrow).toEqual(narrow);
}
test("Test filters are present on tip request", testCorrectFilters);

function testFiltersFunctionality() {
    let find = mount(<FindAddDialog filters={singleFilters}/>);
    expect(find.instance().isFilterChecked("type", "toast")).toEqual(false);
    find.instance().checkFilter("type", "toast");
    expect(find.instance().isFilterChecked("type", "toast")).toEqual(true);
    find.instance().checkFilter("type", "toast");
    expect(find.instance().isFilterChecked("type", "toast")).toEqual(false);

}
test("Test filters checkboxes function properly", testFiltersFunctionality);

function testCapitalizeLabelMethod() {
    let find = mount(<FindAddDialog filters={doubleFilters}/>);
    const actual = find.instance().capitalizeLabel("chicken");
    expect(actual).toEqual("Chicken");
}
test("Test capitalizeLabel method", testCapitalizeLabelMethod);

function testUpdateFilterState() {
    let find = mount(<FindAddDialog filters={singleFilters}/>);
    const filterArray = [{"name": "sandwich", "values": ["chicken", "club", "taco"]}];
    find.instance().updateFilterState(filterArray);
    const expected = [{"name": "type", "values": []}, {"name": "sandwich", "values": []}];
    expect(find.state().filters).toEqual(expected);
    expect(find.state().dropDownOpen).toEqual([{"type": false}, {"sandwich": false}]);
}
test("test updateFilterState method", testUpdateFilterState);

function testOptionChange() {
    let find = mount(<FindAddDialog filters={doubleFilters}/>);
    find.instance().optionChange([{value: "Stew", label: "Stew"}]);
    const expected = [{"name": "type", "values": []}, {"name": "country", "values": ["Stew"]}];
    expect(find.state().filters).toEqual(expected);
    find.instance().optionChange([]);
    const expectedT = [{"name": "type", "values": []}, {"name": "country", "values": []}];
    expect(find.state().filters).toEqual(expectedT);
}
test("Test optionChange method", testOptionChange);

function testGetRemovedCountry() {
    let find = mount(<FindAddDialog filters={doubleFilters}/>);
    find.state().optionsSelected =
        [{value: "chi", label: "Chi"}, {value: "bang", label: "Bang"}];
    const actualMissing = find.instance().getRemovedCountry([{value: "chi", label: "Chi"}]);
    expect(actualMissing).toEqual("Bang");
}
test("Test getRemovedCountry method", testGetRemovedCountry);

function testGenerateCountryOptions() {
    let find = mount(<FindAddDialog filters={doubleFilters}/>);
    const actual = find.instance().generateCountryOptions(["chicken", "sandwich"]);
    const expected = [{value: "chicken", label: "Chicken"}, {value: "sandwich", label: "Sandwich"}];
    expect(actual).toEqual(expected);
}
test("Test generateCountryOptions method", testGenerateCountryOptions);
