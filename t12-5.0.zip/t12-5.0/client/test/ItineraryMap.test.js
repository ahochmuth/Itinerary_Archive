import './enzyme.config.js';
import React from 'react';
import { mount, shallow } from 'enzyme';
import ItineraryMap from '../src/components/Application/Itinerary/ItineraryMap.jsx';


const threePlaces = [
    {"id":"dnvr", "name":"Denver",       "latitude": "39.7392",   "longitude": "-104.9903"},
    {"id":"bldr", "name":"Boulder",      "latitude": "40.01499",  "longitude": "-105.27055"},
    {"id":"foco", "name":"Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"},
];

const threeMarkers = [{"name":"Denver", "markFlag": "false"},{"name":"Boulder", "markFlag": "false"},{"name":"Fort Collins", "markFlag": "false"}];

function testRenderMap() {
    let itin = shallow(<ItineraryMap markersChecked={threeMarkers} places={threePlaces}/>);
    // expect(true).toEqual(false);
}
test("Test that map renders without exceptions", testRenderMap)
