import './enzyme.config.js';
import React from 'react';
import { mount, shallow } from 'enzyme';
import App from '../src/components/App';

function testApp() {
  const app = shallow(<App/>);

  let numberOfApplications = app.find('Application').length;
  expect(numberOfApplications).toEqual(1);
}
test('Shallow App test', testApp);

function testPageSwitch() {
  const app = shallow(<App/>);

  let numberOfApplications = app.find('Application').length;
  expect(numberOfApplications).toEqual(1);
  app.instance().setAppPage("team");
  app.update();
  let pageOpen = app.state().current_page;
  expect(pageOpen).toEqual("team");
}

test('App state change test', testPageSwitch);
