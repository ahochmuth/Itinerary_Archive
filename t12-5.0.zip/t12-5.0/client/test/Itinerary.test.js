import './enzyme.config.js';
import React from 'react';
import {mount, shallow} from 'enzyme';
import Itinerary from '../src/components/Application/Itinerary/Itinerary';
import {Button} from 'reactstrap';
import {findButton, buttonIsPresent} from './test-utils.js';

const threePlaces = [
    {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
    {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
    {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"},
];

const dmsThreePlaces = [
    {"id": "paris", "name": "Paris", "latitude": "48.8566° N", "longitude": "2.3522° E"},
    {"id": "cptwn", "name": "Cape Town", "latitude": "33.9249° S", "longitude": "18.4241° E"},
    {"id": "nyc", "name": "New York", "latitude": "40.7128° N", "longitude": "74.0060° W"}
];

const threeMarkers = [{"name": "Denver", "markFlag": "true"}, {
    "name": "Boulder",
    "markFlag": "false"
}, {"name": "Fort Collins", "markFlag": "false"}]

const optimizations = ["none", "short", "shorter"];

const filters = [{"name": "type",
    "values": ["airport","heliport","balloonport","closed"]}
    ];

const noPlaces = [];

const noMarkers = [];

const startOptions = {
    activeUnit: 'miles',
    units: {
        miles: 3958.761316
    }
};

const clientSettings = {
    clientSettings: {
        serverPort: 8088
    },
};

const attributesChecked = {
    id: true,
    name: true,
    latitude: true,
    longitude: true,
    distance: true,
    cumulativeDistance: true,
};

function mockItineraryResponseThreePlacesOptimization() {
    fetch.mockResponse(JSON.stringify(
        {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": {
                "title": "Fantastic Voyage",
                "earthRadius": "3958.761316",
                "optimizations": "short"
            },
            "places": [
                {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
                {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
                {"id": "drag", "name": "Longmont", "latitude": "40.167207", "longitude": "-105.101928"},
                {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}
            ],
            "markersChecked": [{"name": "Denver", "markFlag": "false"}, {
                "name": "Boulder",
                "markFlag": "true"
            }, {"name": "Longmount", "markFlag": "false"}, {"name": "Fort Collins", "markFlag": "false"}],
            "distances": [24, 14, 29, 59]
        }));
}

function mockItineraryResponseTwoOptimization() {
    fetch.mockResponse(JSON.stringify(
        {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": {
                "title": "Fantastic Voyage",
                "earthRadius": "3958.761316",
                "optimizations": "shorter"
            },
            "places": [
                {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
                {"id": "uiuy", "name": "uiuyiyuiyu", "latitude": "40.01499", "longitude": "-104.98"},
                {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
                {"id": "plac", "name": "place", "latitude": "40.3", "longitude": "-105.27055"},
                {"id": "sdaf", "name": "sdafasfsfs", "latitude": "40.3", "longitude": "-104.98"},
                {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}
            ],
            "markersChecked": [{"name": "Denver", "markFlag": "false"}, {"name": "uiuyiyuiyu", "markFlag": "false"}, {
                "name": "Boulder",
                "markFlag": "false"
            }, {"name": "place", "markFlag": "false"}, {
                "name": "sdafasfsfs",
                "markFlag": "false"
            }, {"name": "Fort Collins", "markFlag": "false"}],
            "distances": [19, 20, 20, 22, 20, 24]
        }));
}


function mockItineraryResponseDMSOptimization() {
    fetch.mockResponse(JSON.stringify(
        {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": {
                "title": "Fantastic Voyage",
                "earthRadius": "3958.761316",
                "optimizations": "short"
            },
            "places": [
                {"id": "paris", "name": "Paris", "latitude": "48.8566", "longitude": "2.3522"},
                {"id": "nyc", "name": "New York", "latitude": "40.7128", "longitude": "-74.006"},
                {"id": "cptwn", "name": "Cape Town", "latitude": "-33.9249", "longitude": "18.4241"},
            ],
            "markersChecked": [{"name": "Paris", "markFlag": "false"}, {
                "name": "New York",
                "markFlag": "false"
            }, {"name": "Cape Town", "markFlag": "false"}],
            "distances": [420, 69, 100]
        }));
}

function mockItineraryResponseThreePlaces() {
    fetch.mockResponse(JSON.stringify(
        {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": {
                "title": "Fantastic Voyage",
                "earthRadius": "3958.761316"
            },
            "places": [
                {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
                {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
                {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}],
            "markersChecked": [{"name": "Denver", "markFlag": "true"}, {
                "name": "Boulder",
                "markFlag": "false"
            }, {"name": "Fort Collins", "markFlag": "false"}],
            "distances": [29, 58, 65],
            "placeToAdd": {"id": "plac", "name": "place", "latitude": "1", "longitude": "-1"}
        }));
}

function mockItineraryResponseNoPlaces() {
    fetch.mockResponse(JSON.stringify(
        {
            "requestType": "itinerary",
            "requestVersion": 4,
            "options": {
                "title": "Very Boring Voyage",
                "earthRadius": "3958.761316"
            },
            "places": [],
            "markersChecked": [],
            "distances": []
        }));
}

function testItineraryState() {
    let createErrorBanner = jest.fn();
    mockItineraryResponseNoPlaces();
    let itin = mount(<Itinerary
        options={startOptions}
        places={noPlaces}
        markersChecked={noMarkers}
        settings={clientSettings}
        optimizations={optimizations}
        filters={filters}
        createErrorBanner={createErrorBanner}
        attributesChecked={attributesChecked}/>);

    let expected = 0;
    let options = itin.state().options;
    let actual = Object.keys(options).length;
    expect(actual).toEqual(expected);


    let expectedRErrorMessage = null;
    let actualErrorMessage = itin.state().errorMessage;
    expect(actualErrorMessage).toEqual(expectedRErrorMessage);


    let expectedPlacesCount = 0;
    let places = itin.props().places;
    let actualPlacesCount = Object.keys(places).length;
    expect(actualPlacesCount).toEqual(expectedPlacesCount);

    let expectedMarkersCount = 0;
    let mark = itin.props().markersChecked;
    let actualMarkersCount = Object.keys(mark).length;
    expect(actualMarkersCount).toEqual(expectedMarkersCount);

    let expectedDistanceCount = 0;
    let distances = itin.state().distances;
    let actualDistanceCount = Object.keys(distances).length;
    expect(actualDistanceCount).toEqual(expectedDistanceCount);

}

test("Testing Itinerary's initial state", testItineraryState);

function testItineraryDistance() {
    mockItineraryResponseThreePlaces();
    let itin = shallow(<Itinerary options={startOptions} places={noPlaces}
                                  optimizations={optimizations}
                                  settings={clientSettings}/>);

    let expectedTotalDistance = 152;
    let actualTotalDistance = itin.instance().addTotalDistance([29, 58, 65]);
    expect(actualTotalDistance).toEqual(expectedTotalDistance);
}

test("Testing total distance calculator", testItineraryDistance);

function testDistanceCalc() {
    mockItineraryResponseThreePlaces();
    let itin = shallow(<Itinerary options={startOptions}
                                  places={threePlaces}
                                  optimizations={optimizations}
                                  settings={clientSettings}/>);
    itin.setState({
        distances: [],
    });
    itin.instance().componentDidUpdate({}, {});
    itin.update()
    let actualDistances = itin.state().distances;
    // let expectedDistances = [29, 58, 65];

    // TODO: Figure out why this test succeeds.
    expect(actualDistances).toEqual([]);
}

test("Testing render of list", testDistanceCalc);


function genDNDevent(sourceIndex, destIndex) {
    return {
        source: {
            droppableId: "itineraryDroppable",
            index: sourceIndex,
        },
        destination: {
            droppableId: "itineraryDroppable",
            index: destIndex,
        },
        draggableId: "foo",
    };
}

function testDragAndDrop() {
    mockItineraryResponseThreePlaces();
    let onUpdate = jest.fn();
    let itin = shallow(<Itinerary options={startOptions}
                                  settings={clientSettings}
                                  places={threePlaces}
                                  markersChecked={threeMarkers}
                                  optimizations={optimizations}
                                  updateMarkers={onUpdate}
                                  updatePlaces={onUpdate}/>);
    itin.setState({
        distances: [],
    });
    itin.update();

    itin.instance().onDragEnd(genDNDevent(0, 1));

    itin.update();

    const swappedPlaces = [
        {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
        {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
        {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"},
    ];

    expect(onUpdate).toHaveBeenCalledWith(swappedPlaces);
}

test("Testing drag and drop callback", testDragAndDrop);

function testDragAndDropRemove() {
    mockItineraryResponseThreePlaces();
    const updatePlaces = jest.fn()
    const updateMarkers = jest.fn()
    const removeMarkerFromItinerary = jest.fn()
    let itin = shallow(<Itinerary updatePlaces={updatePlaces}
                                  updateMarkers={updateMarkers}
                                  options={startOptions}
                                  places={threePlaces}
                                  removeMarkerFromItinerary={removeMarkerFromItinerary}
                                  markersChecked={threeMarkers}
                                  optimizations={optimizations}
                                  settings={clientSettings}/>);

    itin.instance().onDragEnd({
        source: {
            droppableId: "itineraryDroppable",
            index: 0,
        },
        destination: null,
        draggableId: "foo",
    });

    const firstPlaceRemoved = [
        {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
        {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"},
    ];
    const firstMarkerRemoved = [{"name": "Boulder", "markFlag": "false"}, {"name": "Fort Collins", "markFlag": "false"}];
    expect(updatePlaces).toHaveBeenCalledWith(firstPlaceRemoved);
    expect(removeMarkerFromItinerary).toHaveBeenCalledWith("Denver");
}

test("Testing drag and drop outside Droppable", testDragAndDropRemove);

function testDragAndDropToSamePlace() {
    mockItineraryResponseThreePlaces();
    const simon = jest.fn()
    let itin = shallow(<Itinerary options={startOptions}
                                  places={threePlaces}
                                  markersChecked={threeMarkers}
                                  settings={clientSettings}
                                  optimizations={optimizations}/>);
    itin.setState({
        distances: [],
        options: {
            title: "My Trip"
        }
    });
    itin.update();

    itin.instance().onDragEnd(genDNDevent(1, 1));

    itin.update();


    itin.find(itin.instance().onDragEnd)
    expect(simon).not.toHaveBeenCalledWith()
    // const firstCityActual = itin.props().places[0].name;
    // const secondCityActual = itin.props().places[1].name;
    // const firstCityExpected = "Denver";
    // const secondCityExpected = "Boulder";
    //
    // expect(firstCityActual).toEqual(firstCityExpected);
    // expect(secondCityActual).toEqual(secondCityExpected);
}

test("Testing drag and drop to same place", testDragAndDropToSamePlace);

function testReverseNoop() {
    const onUpdate = jest.fn();
    const itin = shallow(<Itinerary options={startOptions}
                                    places={noPlaces}
                                    markersChecked={noMarkers}
                                    settings={clientSettings}
                                    optimizations={optimizations}
                                    updatePlaces={onUpdate}/>);
    const reverseBtn = findButton(itin, "Reverse Trip");
    reverseBtn.prop('onClick')()
    // reversing no places does nothing
    expect(onUpdate).not.toHaveBeenCalled();
}

test("Reverse itinerary list (0 places)", testReverseNoop);


function testReverseThree() {
    const onUpdate = jest.fn();
    const updateMarkers = jest.fn();
    mockItineraryResponseThreePlaces();
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    markersChecked={threeMarkers}
                                    settings={clientSettings}
                                    optimizations={optimizations}
                                    updateMarkers={updateMarkers}
                                    updatePlaces={onUpdate}/>);
    const reverseBtn = findButton(itin, "Reverse Trip");
    reverseBtn.prop('onClick')();
    const reversed = [
        {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
        {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"},
        {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
    ];
    const reversedMarkers = [{"name": "Denver", "markFlag": "true"}, {"name": "Fort Collins", "markFlag": "false"}, {"name": "Boulder", "markFlag": "false"}];
    expect(onUpdate).toHaveBeenCalledWith(reversed);
    expect(updateMarkers).toHaveBeenCalledWith(reversedMarkers);
}

test("Reverse itinerary list (3 places)", testReverseThree);

function testOptimize(done) {
    mockItineraryResponseThreePlacesOptimization();
    const onUpdate = jest.fn();
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    optimizations={optimizations}
                                    updatePlaces={onUpdate}/>);
    const shortOpt = findButton(itin, "Short");
    shortOpt.prop('onClick')();

    const optimized = [
        {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
        {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
        {"id": "drag", "name": "Longmont", "latitude": "40.167207", "longitude": "-105.101928"},
        {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}
    ];

    // TODO: Figure out a better way to wait for a request to complete.
    setTimeout(() => {
        expect(onUpdate).toHaveBeenCalledWith(optimized);
        const expectedDistances = [24, 14, 29, 59];
        const actualDistances = itin.state().distances;
        expect(actualDistances).toEqual(expectedDistances);
        done();
    }, 100);
}

test("Nearest neighbor optimize", testOptimize);

function testTwoOptimize(done) {
    mockItineraryResponseTwoOptimization();
    const onUpdate = jest.fn();

    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    updatePlaces={onUpdate}
                                    optimizations={optimizations}/>);
    const shortOpt = findButton(itin, "Shorter");
    shortOpt.prop('onClick')();

    const optimized = [
        {"id": "dnvr", "name": "Denver", "latitude": "39.7392", "longitude": "-104.9903"},
        {"id": "uiuy", "name": "uiuyiyuiyu", "latitude": "40.01499", "longitude": "-104.98"},
        {"id": "bldr", "name": "Boulder", "latitude": "40.01499", "longitude": "-105.27055"},
        {"id": "plac", "name": "place", "latitude": "40.3", "longitude": "-105.27055"},
        {"id": "sdaf", "name": "sdafasfsfs", "latitude": "40.3", "longitude": "-104.98"},
        {"id": "foco", "name": "Fort Collins", "latitude": "40.585258", "longitude": "-105.084419"}
    ];

    // TODO: Figure out a better way to wait for a request to complete.
    setTimeout(() => {
        expect(onUpdate).toHaveBeenCalledWith(optimized);
        const expectedDistances = [19, 20, 20, 22, 20, 24];
        const actualDistances = itin.state().distances;
        expect(actualDistances).toEqual(expectedDistances);
        done();
    }, 200);
}

test("2-opt optimize", testTwoOptimize);

function testOneOptButtonDoesntRender() {
    mockItineraryResponseTwoOptimization();
    const onUpdate = jest.fn();
    const opts = ["none"];
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    updatePlaces={onUpdate}
                                    optimizations={opts}/>);
    const shortOpt = buttonIsPresent(itin, "Short");

    let expected = false;
    expect(shortOpt).toEqual(expected);

}

test("Test Short does not render if not present", testOneOptButtonDoesntRender);

function testTwoOptButtonDoesntRender() {
    mockItineraryResponseTwoOptimization();
    const onUpdate = jest.fn();
    const opts = ["none", "short"];
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    updatePlaces={onUpdate}
                                    optimizations={opts}/>);
    const shortOpt = buttonIsPresent(itin, "Shorter");

    let expected = false;
    expect(shortOpt).toEqual(expected);

}

test("Test Shorter does not render if not present", testTwoOptButtonDoesntRender);

function testThreeOptButtonDoesntRender() {
    mockItineraryResponseTwoOptimization();
    const onUpdate = jest.fn();
    const opts = ["none", "short", "shorter"];
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    updatePlaces={onUpdate}
                                    optimizations={opts}/>);
    const shortOpt = buttonIsPresent(itin, "Shortest");

    let expected = false;
    expect(shortOpt).toEqual(expected);

}

test("Test Shortest does not render if not present", testThreeOptButtonDoesntRender);

function testThreeOptButtonRender() {
    mockItineraryResponseTwoOptimization();
    const onUpdate = jest.fn();
    const opts = ["none", "short", "shorter", "shortest"];
    const itin = shallow(<Itinerary options={startOptions}
                                    places={threePlaces}
                                    settings={clientSettings}
                                    updatePlaces={onUpdate}
                                    optimizations={opts}/>);
    const shortOpt = buttonIsPresent(itin, "Shortest");

    let expected = true;
    expect(shortOpt).toEqual(expected);
}

test("Test Shortest does render if present", testThreeOptButtonRender);

function testDMSInput(done) {
    const onUpdate = jest.fn();
    mockItineraryResponseDMSOptimization();
    const itin = shallow(<Itinerary options={startOptions}
                                    places={dmsThreePlaces}
                                    settings={clientSettings}
                                    optimizations={optimizations}
                                    updatePlaces={onUpdate}/>);
    const shortOpt = findButton(itin, "Short");
    shortOpt.prop('onClick')();

    // Expect nyc before cape town, because nyc is closer
    // Also expect places in original dms format
    const optimized = [
        {"id": "paris", "name": "Paris", "latitude": "48.8566° N", "longitude": "2.3522° E"},
        {"id": "nyc", "name": "New York", "latitude": "40.7128° N", "longitude": "74.0060° W"},
        {"id": "cptwn", "name": "Cape Town", "latitude": "33.9249° S", "longitude": "18.4241° E"},
    ];

    setTimeout(() => {
        expect(onUpdate).toHaveBeenCalledWith(optimized);
        // const expectedDistances = [24, 14, 29, 59];
        // const actualDistances = itin.state().distances;
        // expect(actualDistances).toEqual(expectedDistances);
        done();
    }, 100);
}

test("Optimizing a DMS itinerary", testDMSInput);


