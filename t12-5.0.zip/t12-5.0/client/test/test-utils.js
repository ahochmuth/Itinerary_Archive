import {Button} from 'reactstrap';

function getAllButtons(mounted, name) {
    const buttons = mounted.find(Button);
    let found = [];
    buttons.forEach(button => {
        // console.error("looking for " + name + " see " + button.html())
        const regex = new RegExp("\\b" + name + "\\b");
        if(button.html().match(regex)) {
            // console.error("found")
            // This line really pushes my buttons
            found.push(button);
        }
    });
    return found
}

export function findButton(mounted, name) {
    const found = getAllButtons(mounted, name);
    if(found.length > 1) {
        throw "Ambiguous button selector"
    }
    if(found.length < 1) {
        throw "Button not found"
    }
    return found[0];
}

export function buttonIsPresent(mounted, name) {
    const found = getAllButtons(mounted, name);
    return found.length > 0;
}

