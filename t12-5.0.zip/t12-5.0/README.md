
# t12 - Smells Like Team Spirit 

![Build Badge](https://api.travis-ci.com/csucs314s19/t12.svg?token=UuHvxYbqJw11HarQzoGp&branch=master)

![Image](https://liquipedia.net/commons/images/7/77/Team_Spirit_2016.png)

Coding with spirit.
# Member Information

| name          | eID      | GitHub Username | Email                      |
|---------------|----------|-----------------|----------------------------|
| Nick ODell    | njodell  | nickodell       | njodell@rams.colostate.edu |
| AndreHochmuth | andreh   | op0126          | andreh@rams.colostate.edu  |
| Simon Nardos  | simonard | simonnardos     | simonard@rams.colostate.edu|
| Mike Popesh   | mpopesh  | Alabastor05     | mpopesh@rams.colostate.edu |
