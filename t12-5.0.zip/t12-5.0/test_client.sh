#!/usr/bin/env bash
(cd client; ./node_modules/.bin/jest "$@")
